// entity/User.java
package entity;

import java.time.LocalDate;

public class User {
    private Integer userID;
    private String userName;
    private String userEmail;
    private String userPassword;
    private String userGender;
    private LocalDate userDOB;
    private String userRole;

    public User() {}

    public User(Integer userID, String userName, String userEmail, String userPassword,
                String userGender, LocalDate userDOB, String userRole) {
        this.userID = userID;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.userGender = userGender;
        this.userDOB = userDOB;
        this.userRole = userRole;
    }

    // getters & setters
    public Integer getUserID() { return userID; }
    public void setUserID(Integer userID) { this.userID = userID; }
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    public String getUserEmail() { return userEmail; }
    public void setUserEmail(String userEmail) { this.userEmail = userEmail; }
    public String getUserPassword() { return userPassword; }
    public void setUserPassword(String userPassword) { this.userPassword = userPassword; }
    public String getUserGender() { return userGender; }
    public void setUserGender(String userGender) { this.userGender = userGender; }
    public java.time.LocalDate getUserDOB() { return userDOB; }
    public void setUserDOB(java.time.LocalDate userDOB) { this.userDOB = userDOB; }
    public String getUserRole() { return userRole; }
    public void setUserRole(String userRole) { this.userRole = userRole; }
}