// entity/Employee.java
package entity;

import java.time.LocalDate;

public abstract class Employee extends User {
    public Employee(Integer userID, String userName, String userEmail, String userPassword,
                    String userGender, LocalDate userDOB, String userRole) {
        super(userID, userName, userEmail, userPassword, userGender, userDOB, userRole);
    }
}