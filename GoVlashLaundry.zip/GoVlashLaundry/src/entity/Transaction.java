// entity/Transaction.java
package entity;

import java.time.LocalDate;

public class Transaction {
    private Integer transactionID;
    private Integer serviceID;
    private Integer customerID;
    private Integer receptionistID;
    private Integer laundryStaffID;
    private LocalDate transactionDate;
    private String transactionStatus;
    private Double totalWeight;
    private String transactionNotes;

    public Transaction() {}

    public Transaction(Integer transactionID, Integer serviceID, Integer customerID,
                       Integer receptionistID, Integer laundryStaffID, LocalDate transactionDate,
                       String transactionStatus, Double totalWeight, String transactionNotes) {
        this.transactionID = transactionID;
        this.serviceID = serviceID;
        this.customerID = customerID;
        this.receptionistID = receptionistID;
        this.laundryStaffID = laundryStaffID;
        this.transactionDate = transactionDate;
        this.transactionStatus = transactionStatus;
        this.totalWeight = totalWeight;
        this.transactionNotes = transactionNotes;
    }

    public Integer getTransactionID() { return transactionID; }
    public void setTransactionID(Integer transactionID) { this.transactionID = transactionID; }
    public Integer getServiceID() { return serviceID; }
    public void setServiceID(Integer serviceID) { this.serviceID = serviceID; }
    public Integer getCustomerID() { return customerID; }
    public void setCustomerID(Integer customerID) { this.customerID = customerID; }
    public Integer getReceptionistID() { return receptionistID; }
    public void setReceptionistID(Integer receptionistID) { this.receptionistID = receptionistID; }
    public Integer getLaundryStaffID() { return laundryStaffID; }
    public void setLaundryStaffID(Integer laundryStaffID) { this.laundryStaffID = laundryStaffID; }
    public java.time.LocalDate getTransactionDate() { return transactionDate; }
    public void setTransactionDate(java.time.LocalDate transactionDate) { this.transactionDate = transactionDate; }
    public String getTransactionStatus() { return transactionStatus; }
    public void setTransactionStatus(String transactionStatus) { this.transactionStatus = transactionStatus; }
    public Double getTotalWeight() { return totalWeight; }
    public void setTotalWeight(Double totalWeight) { this.totalWeight = totalWeight; }
    public String getTransactionNotes() { return transactionNotes; }
    public void setTransactionNotes(String transactionNotes) { this.transactionNotes = transactionNotes; }
}