// entity/Receptionist.java
package entity;

import java.time.LocalDate;

public class Receptionist extends Employee {
    public Receptionist(Integer userID, String userName, String userEmail, String userPassword,
                        String userGender, LocalDate userDOB) {
        super(userID, userName, userEmail, userPassword, userGender, userDOB, "Receptionist");
    }
}