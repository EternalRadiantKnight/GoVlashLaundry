// entity/Notification.java
package entity;

import java.time.LocalDateTime;

public class Notification {
    private Integer notificationID;
    private Integer recipientID;
    private String notificationMessage;
    private LocalDateTime createdAt;
    private Boolean isRead;

    public Notification() {}

    public Notification(Integer notificationID, Integer recipientID, String notificationMessage,
                        LocalDateTime createdAt, Boolean isRead) {
        this.notificationID = notificationID;
        this.recipientID = recipientID;
        this.notificationMessage = notificationMessage;
        this.createdAt = createdAt;
        this.isRead = isRead;
    }

    public Integer getNotificationID() { return notificationID; }
    public void setNotificationID(Integer notificationID) { this.notificationID = notificationID; }
    public Integer getRecipientID() { return recipientID; }
    public void setRecipientID(Integer recipientID) { this.recipientID = recipientID; }
    public String getNotificationMessage() { return notificationMessage; }
    public void setNotificationMessage(String notificationMessage) { this.notificationMessage = notificationMessage; }
    public java.time.LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(java.time.LocalDateTime createdAt) { this.createdAt = createdAt; }
    public Boolean getIsRead() { return isRead; }
    public void setIsRead(Boolean isRead) { this.isRead = isRead; }
}