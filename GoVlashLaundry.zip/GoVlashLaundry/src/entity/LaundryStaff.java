// entity/LaundryStaff.java
package entity;

import java.time.LocalDate;

public class LaundryStaff extends Employee {
    public LaundryStaff(Integer userID, String userName, String userEmail, String userPassword,
                        String userGender, LocalDate userDOB) {
        super(userID, userName, userEmail, userPassword, userGender, userDOB, "Laundry Staff");
    }
}