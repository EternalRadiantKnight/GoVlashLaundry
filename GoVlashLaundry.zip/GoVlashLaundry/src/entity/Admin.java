// entity/Admin.java
package entity;

import java.time.LocalDate;

public class Admin extends Employee {
    public Admin(Integer userID, String userName, String userEmail, String userPassword,
                 String userGender, LocalDate userDOB) {
        super(userID, userName, userEmail, userPassword, userGender, userDOB, "Admin");
    }
}