package model;
import config.Database;
import entity.Service;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ServiceModel {
    public boolean insertService(Service service) {
        String sql = "INSERT INTO Service (serviceName, serviceDescription, servicePrice, serviceDuration) VALUES (?, ?, ?, ?)";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, service.getServiceName());
            ps.setString(2, service.getServiceDescription());
            ps.setDouble(3, service.getServicePrice());
            ps.setInt(4, service.getServiceDuration());
            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) { if (keys.next()) service.setServiceID(keys.getInt(1)); }
                return true;
            }
            return false;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public boolean updateService(Service service) {
        String sql = "UPDATE Service SET serviceName=?, serviceDescription=?, servicePrice=?, serviceDuration=? WHERE serviceID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, service.getServiceName());
            ps.setString(2, service.getServiceDescription());
            ps.setDouble(3, service.getServicePrice());
            ps.setInt(4, service.getServiceDuration());
            ps.setInt(5, service.getServiceID());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public boolean deleteService(int id) {
        String sql = "DELETE FROM Service WHERE serviceID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id); return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public List<Service> getAllServices() {
        List<Service> list = new ArrayList<>();
        String sql = "SELECT * FROM Service";
        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Service(
                        rs.getInt("serviceID"),
                        rs.getString("serviceName"),
                        rs.getString("serviceDescription"),
                        rs.getDouble("servicePrice"),
                        rs.getInt("serviceDuration")
                ));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Service getServiceById(int id) {
        String sql = "SELECT * FROM Service WHERE serviceID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Service(rs.getInt("serviceID"),
                            rs.getString("serviceName"),
                            rs.getString("serviceDescription"),
                            rs.getDouble("servicePrice"),
                            rs.getInt("serviceDuration"));
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }
}