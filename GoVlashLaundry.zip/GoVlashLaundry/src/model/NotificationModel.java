package model;
import config.Database;
import entity.Notification;
import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class NotificationModel {

    public boolean insertNotification(Notification n) {
        String sql = "INSERT INTO Notification (recipientID, notificationMessage, createdAt, isRead) VALUES (?, ?, ?, ?)";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, n.getRecipientID());
            ps.setString(2, n.getNotificationMessage());
            ps.setTimestamp(3, Timestamp.valueOf(n.getCreatedAt()));
            ps.setBoolean(4, n.getIsRead());
            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) { if (keys.next()) n.setNotificationID(keys.getInt(1)); }
                return true;
            }
        } catch (Exception e) { e.printStackTrace(); }
        return false;
    }

    public List<Notification> getNotificationsByRecipient(int recipientID) {
        List<Notification> list = new ArrayList<>();
        String sql = "SELECT * FROM Notification WHERE recipientID=? ORDER BY createdAt DESC";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, recipientID);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Notification(
                            rs.getInt("notificationID"),
                            rs.getInt("recipientID"),
                            rs.getString("notificationMessage"),
                            rs.getTimestamp("createdAt").toLocalDateTime(),
                            rs.getBoolean("isRead")
                    ));
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Notification getNotificationByID(int id) {
        String sql = "SELECT * FROM Notification WHERE notificationID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Notification(
                            rs.getInt("notificationID"),
                            rs.getInt("recipientID"),
                            rs.getString("notificationMessage"),
                            rs.getTimestamp("createdAt").toLocalDateTime(),
                            rs.getBoolean("isRead")
                    );
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public boolean markAsRead(int id) {
        String sql = "UPDATE Notification SET isRead=true WHERE notificationID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id); return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public boolean deleteNotification(int id) {
        String sql = "DELETE FROM Notification WHERE notificationID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id); return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }
}