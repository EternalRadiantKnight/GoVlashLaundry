package model;

import config.Database;
import entity.*;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class UserModel {

    // ======== LOGIN SESSION TRACKER ========
    private static User lastLoggedInUser;

    public User getLastLoggedInUser() {
        return lastLoggedInUser;
    }

    // ======== INSERT USER ========
    public boolean insertUser(User u) {
        String sql = "INSERT INTO User (userName, userEmail, userPassword, userGender, userDOB, userRole) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, u.getUserName());
            ps.setString(2, u.getUserEmail());
            ps.setString(3, u.getUserPassword());
            ps.setString(4, u.getUserGender());
            ps.setDate(5, Date.valueOf(u.getUserDOB()));
            ps.setString(6, u.getUserRole());

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) u.setUserID(keys.getInt(1));
                }
                return true;
            }

        } catch (Exception e) { e.printStackTrace(); }

        return false;
    }

    // ======== LOGIN (FINAL VERSION, HANYA 1 METHOD) ========
    public User login(String email, String password) {
        String sql = "SELECT * FROM User WHERE userEmail=? AND userPassword=?";

        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    User u = buildUser(rs);
                    lastLoggedInUser = u;   // save session
                    return u;
                }
            }

        } catch (Exception e) { e.printStackTrace(); }

        return null;
    }
    
    public User getUserByID(int id) {
        String sql = "SELECT * FROM User WHERE userID=?";

        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return buildUser(rs);
            }

        } catch (Exception e) { e.printStackTrace(); }

        return null;
    }

    // ======== GET USER BY EMAIL ========
    public User getUserByEmail(String email) {
        String sql = "SELECT * FROM User WHERE userEmail=?";

        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return buildUser(rs);
            }

        } catch (Exception e) { e.printStackTrace(); }

        return null;
    }

    // ======== GET USER BY NAME ========
    public User getUserByName(String name) {
        String sql = "SELECT * FROM User WHERE userName=?";

        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setString(1, name);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return buildUser(rs);
            }

        } catch (Exception e) { e.printStackTrace(); }

        return null;
    }

    // ======== GET ALL EMPLOYEES ========
    public List<User> getAllEmployees() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM User WHERE userRole IN ('Admin', 'Receptionist', 'Laundry Staff')";

        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) list.add(buildUser(rs));

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }
    
    public List<User> getCustomers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM User WHERE userRole = 'Customer'";

        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) list.add(buildUser(rs));

        } catch (Exception e) { e.printStackTrace(); }

        return list;
    }

    // ======== DELETE USER (DIPAKAI UNTUK DELETE EMPLOYEE) ========
    public boolean deleteUser(int userID) {
        String sql = "DELETE FROM User WHERE userID=?";

        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, userID);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ======== BUILD ENTITY FROM RESULTSET ========
    private User buildUser(ResultSet rs) throws SQLException {
        Integer id = rs.getInt("userID");
        String name = rs.getString("userName");
        String email = rs.getString("userEmail");
        String pass = rs.getString("userPassword");
        String gender = rs.getString("userGender");
        LocalDate dob = rs.getDate("userDOB").toLocalDate();
        String role = rs.getString("userRole");

        switch (role) {
            case "Admin":
                return new Admin(id, name, email, pass, gender, dob);

            case "Receptionist":
                return new Receptionist(id, name, email, pass, gender, dob);

            case "Laundry Staff":
                return new LaundryStaff(id, name, email, pass, gender, dob);

            case "Customer":
                return new Customer(id, name, email, pass, gender, dob);

            default:
                return new User(id, name, email, pass, gender, dob, role);
        }
    }
}