package model;
import config.Database;
import entity.Transaction;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class TransactionModel {

    public boolean insertTransaction(Transaction t) {
        String sql = "INSERT INTO `Transaction` (serviceID, customerID, receptionistID, laundryStaffID, transactionDate, transactionStatus, totalWeight, transactionNotes) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, t.getServiceID());
            ps.setInt(2, t.getCustomerID());

            if (t.getReceptionistID() != null) ps.setInt(3, t.getReceptionistID());
            else ps.setNull(3, Types.INTEGER);

            if (t.getLaundryStaffID() != null) ps.setInt(4, t.getLaundryStaffID());
            else ps.setNull(4, Types.INTEGER);

            LocalDate date = t.getTransactionDate() != null ? t.getTransactionDate() : LocalDate.now();
            ps.setDate(5, Date.valueOf(date));

            ps.setString(6, t.getTransactionStatus() != null ? t.getTransactionStatus() : "Pending");

            if (t.getTotalWeight() != null) ps.setDouble(7, t.getTotalWeight());
            else ps.setNull(7, Types.DOUBLE);

            if (t.getTransactionNotes() != null) ps.setString(8, t.getTransactionNotes());
            else ps.setNull(8, Types.VARCHAR);

            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet keys = ps.getGeneratedKeys()) { if (keys.next()) t.setTransactionID(keys.getInt(1)); }
                return true;
            }
            return false;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public Transaction getTransactionByID(int id) {
        String sql = "SELECT * FROM `Transaction` WHERE transactionID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return map(rs);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return null;
    }

    public List<Transaction> getAllTransactions() {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM `Transaction` ORDER BY transactionDate DESC, transactionID DESC";
        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) list.add(map(rs));
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Transaction> getTransactionsByStatus(String status) {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM `Transaction` WHERE transactionStatus=? ORDER BY transactionDate DESC, transactionID DESC";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, status);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<Transaction> getTransactionsByCustomer(int customerID) {
        List<Transaction> list = new ArrayList<>();
        String sql = "SELECT * FROM `Transaction` WHERE customerID=? ORDER BY transactionDate DESC, transactionID DESC";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, customerID);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) list.add(map(rs));
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public Integer getCustomerIDByTransactionID(int txID) {
        Transaction t = getTransactionByID(txID);
        return t != null ? t.getCustomerID() : null;
    }

    public boolean updateTransaction(Transaction t) {
        String sql = "UPDATE `Transaction` SET serviceID=?, customerID=?, receptionistID=?, laundryStaffID=?, transactionDate=?, transactionStatus=?, totalWeight=?, transactionNotes=? WHERE transactionID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, t.getServiceID());
            ps.setInt(2, t.getCustomerID());
            if (t.getReceptionistID() != null) ps.setInt(3, t.getReceptionistID()); else ps.setNull(3, Types.INTEGER);
            if (t.getLaundryStaffID() != null) ps.setInt(4, t.getLaundryStaffID()); else ps.setNull(4, Types.INTEGER);
            if (t.getTransactionDate() != null) ps.setDate(5, Date.valueOf(t.getTransactionDate())); else ps.setNull(5, Types.DATE);
            ps.setString(6, t.getTransactionStatus());
            if (t.getTotalWeight() != null) ps.setDouble(7, t.getTotalWeight()); else ps.setNull(7, Types.DOUBLE);
            if (t.getTransactionNotes() != null) ps.setString(8, t.getTransactionNotes()); else ps.setNull(8, Types.VARCHAR);
            ps.setInt(9, t.getTransactionID());
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public boolean assignOrderToLaundryStaff(int transactionID, Integer receptionistID, Integer laundryStaffID) {
        String sql = "UPDATE `Transaction` SET receptionistID=?, laundryStaffID=?, transactionStatus=? WHERE transactionID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (receptionistID != null) ps.setInt(1, receptionistID); else ps.setNull(1, Types.INTEGER);
            if (laundryStaffID != null) ps.setInt(2, laundryStaffID); else ps.setNull(2, Types.INTEGER);
            ps.setString(3, "In Progress");
            ps.setInt(4, transactionID);
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public boolean markFinished(int transactionID) {
        String sql = "UPDATE `Transaction` SET transactionStatus=? WHERE transactionID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, "Finished");
            ps.setInt(2, transactionID);
            return ps.executeUpdate() > 0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    public boolean deleteTransaction(int id) {
        String sql = "DELETE FROM `Transaction` WHERE transactionID=?";
        try (Connection c = Database.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id); return ps.executeUpdate()>0;
        } catch (Exception e) { e.printStackTrace(); return false; }
    }

    private Transaction map(ResultSet rs) throws SQLException {
        Integer txId = rs.getInt("transactionID");
        Integer serviceId = rs.getInt("serviceID");
        Integer customerId = rs.getInt("customerID");
        Integer recId = rs.getObject("receptionistID") != null ? rs.getInt("receptionistID") : null;
        Integer staffId = rs.getObject("laundryStaffID") != null ? rs.getInt("laundryStaffID") : null;
        Date d = rs.getDate("transactionDate");
        java.time.LocalDate localDate = d != null ? d.toLocalDate() : null;
        String status = rs.getString("transactionStatus");
        Double weight = rs.getObject("totalWeight") != null ? rs.getDouble("totalWeight") : null;
        String notes = rs.getString("transactionNotes");
        return new Transaction(txId, serviceId, customerId, recId, staffId, localDate, status, weight, notes);
    }
}