package main;

import controller.UserController;
import entity.LaundryStaff;
import entity.User;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import view.*;

import java.util.function.Consumer;

public class MainApp extends Application {

    private Stage primaryStage;
    private User loggedUser;
    private UserController userController = new UserController();

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;
        showLogin();
    }

    private void showLogin() {
        LoginView loginView = new LoginView(user -> {
            this.loggedUser = user;
            switchToMenuFor(user);
        });
        Scene s = new Scene(loginView.getRoot(), 900, 600);
        primaryStage.setTitle("GoVlash Laundry - Login");
        primaryStage.setScene(s);
        primaryStage.show();
    }

    private void switchToMenuFor(User user) {
        String role = user.getUserRole();
        try {
            if ("Admin".equals(role)) {
                AdminMenuView v = new AdminMenuView(this::switchToDashboard, this::logout);
                primaryStage.setScene(new Scene(v.getRoot(), 1000, 700));
                primaryStage.setTitle("Admin Menu");
            } else if ("Receptionist".equals(role)) {
                ReceptionistMenuView v = new ReceptionistMenuView(this::switchToDashboard, this::logout);
                primaryStage.setScene(new Scene(v.getRoot(), 1000, 700));
                primaryStage.setTitle("Receptionist Menu");
            } else if ("Laundry Staff".equals(role)) {
                // Pastikan loggedUser bisa di-cast ke LaundryStaff
                LaundryStaff staff = (LaundryStaff) user;
                LaundryStaffMenuView v = new LaundryStaffMenuView(staff, this::switchToDashboard, this::logout);
                primaryStage.setScene(new Scene(v.getRoot(), 1000, 700));
                primaryStage.setTitle("Laundry Staff Menu");
            } else { // Customer or default
                CustomerMenuView v = new CustomerMenuView(this::switchToDashboard, this::logout, user);
                primaryStage.setScene(new Scene(v.getRoot(), 1000, 700));
                primaryStage.setTitle("Customer Menu");
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            // fallback
            showLogin();
        }
    }

    // show a generic dashboard panel with user info and navigation buttons
    private void switchToDashboard() {
        // For simplicity open a small dashboard with links to other views for the current role
        // We'll reuse the menu views; this method can be called by child views to return to menu.
        if (loggedUser != null) switchToMenuFor(loggedUser);
        else showLogin();
    }

    private void logout() {
        loggedUser = null;
        showLogin();
    }

    public static void main(String[] args) {
        launch(args);
    }
}