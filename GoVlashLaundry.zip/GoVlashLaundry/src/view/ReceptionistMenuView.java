package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class ReceptionistMenuView {

    private VBox root;
    private Runnable onLogout;

    public ReceptionistMenuView(Runnable onBack, Runnable onLogout) {
        this.onLogout = onLogout;
        root = new VBox(12);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Button manageTransactions = new Button("Manage Transactions");
        Button logout = new Button("Logout");

        root.getChildren().addAll(manageTransactions, logout);

        manageTransactions.setOnAction(e -> {
            ManageTransactionReceptionistView v = new ManageTransactionReceptionistView();
            StageHelper.showDialog("Pending Transactions", v.getRoot());
        });

        logout.setOnAction(e -> { if (onLogout != null) onLogout.run(); });
    }

    public Parent getRoot() { return root; }
}