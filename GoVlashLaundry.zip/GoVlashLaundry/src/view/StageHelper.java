package view;

import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class StageHelper {
    public static void showDialog(String title, Parent content) {
        Stage dialog = new Stage();
        dialog.setTitle(title);
        dialog.initModality(Modality.APPLICATION_MODAL);
        dialog.setScene(new Scene(content));
        dialog.setWidth(700);
        dialog.setHeight(500);
        dialog.showAndWait();
    }

    public static void closeOwner(Parent content) {
        Stage stage = (Stage) content.getScene().getWindow();
        stage.close();
    }
}