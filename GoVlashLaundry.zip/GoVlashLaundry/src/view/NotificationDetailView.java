package view;

import entity.Notification;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

public class NotificationDetailView {

    private VBox root;
    private Notification notification;

    public NotificationDetailView(Notification notification) {
        this.notification = notification;
        root = new VBox(8);
        root.setPadding(new Insets(10));
        root.getChildren().addAll(
                new Label("Notification ID: " + notification.getNotificationID()),
                new Label("To: " + notification.getRecipientID()),
                new Label("Created: " + notification.getCreatedAt()),
                new Label("Read: " + notification.getIsRead()),
                new Label("Message:"),
                new Label(notification.getNotificationMessage())
        );
    }

    public Parent getRoot() { return root; }
}