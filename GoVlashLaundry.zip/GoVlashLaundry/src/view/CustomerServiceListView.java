package view;

import controller.ServiceController;
import entity.Service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;

import java.util.List;

public class CustomerServiceListView {

    private BorderPane root = new BorderPane();
    private TableView<Service> table = new TableView<>();
    private ObservableList<Service> data = FXCollections.observableArrayList();
    private ServiceController serviceCtrl = new ServiceController();

    public CustomerServiceListView(java.util.function.Consumer<Service> onSelect) {
        setupTable();
        refresh();

        Button chooseBtn = new Button("Choose Service");
        chooseBtn.setOnAction(e -> {
            Service selected = table.getSelectionModel().getSelectedItem();
            if (selected != null && onSelect != null) onSelect.accept(selected);
        });

        root.setCenter(table);
        root.setBottom(chooseBtn);
        BorderPane.setMargin(chooseBtn, new Insets(10));
    }

    private void setupTable() {

        // --- ID ---
        TableColumn<Service, String> c1 = new TableColumn<>("ID");
        c1.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        String.valueOf(cell.getValue().getServiceID())
                )
        );

        // --- Name ---
        TableColumn<Service, String> c2 = new TableColumn<>("Name");
        c2.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getServiceName()
                )
        );

        // --- Description ---
        TableColumn<Service, String> cDesc = new TableColumn<>("Description");
        cDesc.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        cell.getValue().getServiceDescription()
                )
        );

        // --- Price ---
        TableColumn<Service, String> c3 = new TableColumn<>("Price");
        c3.setCellValueFactory(cell ->
                new javafx.beans.property.SimpleStringProperty(
                        "Rp " + cell.getValue().getServicePrice()
                )
        );

        table.getColumns().addAll(c1, c2, cDesc, c3);
        table.setItems(data);
    }

    private void refresh() {
        List<Service> list = serviceCtrl.getAllServices();
        data.setAll(list);
    }

    public Parent getRoot() { return root; }
}