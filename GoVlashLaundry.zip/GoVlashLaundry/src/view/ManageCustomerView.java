package view;

import controller.UserController;
import entity.User;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import util.AlertUtil;

import java.util.List;

public class ManageCustomerView {

    private BorderPane root;
    private UserController uc = new UserController();
    private TableView<User> table = new TableView<>();
    private ObservableList<User> data = FXCollections.observableArrayList();

    public ManageCustomerView() {

        root = new BorderPane();
        root.setPadding(new Insets(10));

        setupTable();
        refresh();

        TextField search = new TextField();
        search.setPromptText("Search by name or email...");

        Button btnSearch = new Button("Search");
        Button btnReset = new Button("Reset");

        HBox top = new HBox(8, search, btnSearch, btnReset);
        top.setPadding(new Insets(0, 0, 10, 0));
        root.setTop(top);

        btnSearch.setOnAction(e -> {
            String q = search.getText().trim();
            if (q.isEmpty()) return;

            data.clear();

            User u1 = uc.getUserByName(q);
            if (u1 != null && "Customer".equals(u1.getUserRole())) {
                data.add(u1);
            }

            User u2 = uc.getUserByEmail(q);
            if (u2 != null && "Customer".equals(u2.getUserRole()) && !data.contains(u2)) {
                data.add(u2);
            }

            if (data.isEmpty()) {
                AlertUtil.showInfo(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Info", "Customer not found.");
            }
        });

        btnReset.setOnAction(e -> refresh());

        Button btnDelete = new Button("Delete Selected");
        btnDelete.setDisable(true);

        ChangeListener<User> rowSelectListener = (obs, oldVal, newVal) -> {
            btnDelete.setDisable(newVal == null);
        };
        table.getSelectionModel().selectedItemProperty().addListener(rowSelectListener);

        btnDelete.setOnAction(e -> {
            User sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) {
                AlertUtil.showError(root.getScene().getWindow(), "Error", "Select a customer.");
                return;
            }

            boolean confirm = AlertUtil.confirm(root.getScene().getWindow(),
                    "Confirm", "Delete customer " + sel.getUserName() + "?");

            if (!confirm) return;

            boolean ok = uc.deleteCustomer(sel.getUserID());
            if (ok) {
                AlertUtil.showInfo(root.getScene().getWindow(), "Success", "Customer deleted.");
                refresh();
            } else {
                AlertUtil.showError(root.getScene().getWindow(), "Error", "Failed to delete customer.");
            }
        });

        root.setBottom(btnDelete);
        BorderPane.setMargin(btnDelete, new Insets(10, 0, 0, 0));

        root.setCenter(table);
    }

    private void setupTable() {
        TableColumn<User, String> colName = new TableColumn<>("Name");
        colName.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUserName()));

        TableColumn<User, String> colEmail = new TableColumn<>("Email");
        colEmail.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUserEmail()));

        TableColumn<User, String> colGender = new TableColumn<>("Gender");
        colGender.setCellValueFactory(c -> new javafx.beans.property.SimpleStringProperty(c.getValue().getUserGender()));

        table.getColumns().addAll(colName, colEmail, colGender);
        table.setItems(data);
    }

    private void refresh() {
        List<User> list = uc.getCustomers();
        data.setAll(list);
    }

    public Parent getRoot() { return root; }
}