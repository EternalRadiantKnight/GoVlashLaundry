package view;

import controller.NotificationController;
import entity.Notification;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import util.AlertUtil;

import java.util.List;

public class NotificationListView {

    private BorderPane root;
    private NotificationController nc = new NotificationController();
    private ListView<Notification> listView = new ListView<>();
    private ObservableList<Notification> data = FXCollections.observableArrayList();
    private Integer recipientID; // if null show all for admin

    public NotificationListView(Integer recipientID) {
        this.recipientID = recipientID;
        root = new BorderPane();
        root.setPadding(new Insets(8));

        listView.setItems(data);
        listView.setCellFactory(lv -> new javafx.scene.control.ListCell<>() {
            @Override
            protected void updateItem(Notification item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) setText(null);
                else setText((item.getIsRead() ? "[READ] " : "[NEW] ") + item.getNotificationMessage());
            }
        });

        Button open = new Button("Open");
        Button delete = new Button("Delete");
        Button refresh = new Button("Refresh");
        HBox hb = new HBox(6, open, delete, refresh);
        root.setCenter(listView);
        root.setBottom(hb);

        refresh.setOnAction(e -> refreshList());

        open.setOnAction(e -> {
            Notification sel = listView.getSelectionModel().getSelectedItem();
            if (sel == null) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(), "Error", "Pilih notifikasi");
                return;
            }

            // Mark as read ketika dibuka
            if (!sel.getIsRead()) {
                try {
                    nc.markAsRead(sel.getNotificationID());
                } catch (Exception ex) {
                    AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(), "Error", ex.getMessage());
                }
            }

            NotificationDetailView d = new NotificationDetailView(sel);
            StageHelper.showDialog("Notification Detail", d.getRoot());
            refreshList();
        });

        delete.setOnAction(e -> {
            Notification sel = listView.getSelectionModel().getSelectedItem();
            if (sel == null) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(), "Error", "Pilih notifikasi");
                return;
            }

            try {
                nc.deleteNotification(sel.getNotificationID());
                AlertUtil.showInfo(root.getScene() == null ? null : root.getScene().getWindow(), "Sukses", "Notifikasi berhasil dihapus.");
                refreshList();
            } catch (Exception ex) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(), "Error", ex.getMessage());
            }
        });

        refreshList();
    }

    private void refreshList() {
        List<Notification> list;
        if (recipientID == null) {
            list = java.util.Collections.emptyList();
        } else {
            list = nc.getNotificationsByRecipientID(recipientID);
        }
        data.setAll(list);
    }

    public Parent getRoot() {
        return root;
    }
}