package view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import util.AlertUtil;

import java.util.function.Consumer;

public class AdminMenuView {

    private VBox root;
    private Runnable onBack;
    private Runnable onLogout;

    public AdminMenuView(Runnable onBack, Runnable onLogout) {
        this.onBack = onBack;
        this.onLogout = onLogout;
        root = new VBox(12);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Button manageEmployees = new Button("Manage Employees");
        Button manageCustomers = new Button("Manage Customers");
        Button manageServices = new Button("Manage Services");
        Button manageTransactions = new Button("Manage Transactions");
        Button logout = new Button("Logout");

        root.getChildren().addAll(manageEmployees, manageCustomers, manageServices, manageTransactions, logout);

        manageEmployees.setOnAction(e -> {
            ManageEmployeeView v = new ManageEmployeeView();
            StageHelper.showDialog("Manage Employees", v.getRoot());
        });
        manageCustomers.setOnAction(e -> {
            ManageCustomerView v = new ManageCustomerView();
            StageHelper.showDialog("Manage Customers", v.getRoot());
        });
        manageServices.setOnAction(e -> {
            ManageServiceView v = new ManageServiceView();
            StageHelper.showDialog("Manage Services", v.getRoot());
        });
        manageTransactions.setOnAction(e -> {
            ManageTransactionView v = new ManageTransactionView();
            StageHelper.showDialog("Manage Transactions", v.getRoot());
        });
        logout.setOnAction(e -> { if (onLogout != null) onLogout.run(); });
    }

    public Parent getRoot() { return root; }
}