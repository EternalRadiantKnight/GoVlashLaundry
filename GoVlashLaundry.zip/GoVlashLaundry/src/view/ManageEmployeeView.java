package view;

import controller.UserController;
import entity.User;
import javafx.beans.value.ChangeListener;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import util.AlertUtil;

import java.time.LocalDate;
import java.util.List;

public class ManageEmployeeView {

    private BorderPane root;
    private UserController userController = new UserController();
    private TableView<User> table = new TableView<>();
    private ObservableList<User> data = FXCollections.observableArrayList();

    private User loggedInUser;

    public ManageEmployeeView() {
        root = new BorderPane();
        root.setPadding(new Insets(10));

        loggedInUser = userController.getLoggedInUser(); // ambil admin yg login

        setupTable();
        refresh();
        
     // === FILTER ROLE ===
        ChoiceBox<String> filterRole = new ChoiceBox<>();
        filterRole.getItems().addAll("All", "Admin", "Receptionist", "Laundry Staff");
        filterRole.getSelectionModel().selectFirst();

        filterRole.setOnAction(e -> {
            String role = filterRole.getValue();
            if (role.equals("All")) {
                refresh();
            } else {
                List<User> filtered = userController.getUsersByRole(role);
                data.setAll(filtered);
            }
        });

        // Letakkan di TOP
        root.setTop(filterRole);
        BorderPane.setMargin(filterRole, new Insets(0, 0, 10, 0));


        VBox right = new VBox(8);
        right.setPadding(new Insets(8));

        TextField name = new TextField(); name.setPromptText("Name");
        TextField email = new TextField(); email.setPromptText("Email");
        PasswordField pass = new PasswordField(); pass.setPromptText("Password");
        PasswordField conf = new PasswordField(); conf.setPromptText("Confirm Password");

        ChoiceBox<String> gender = new ChoiceBox<>();
        gender.getItems().addAll("Male", "Female");
        gender.getSelectionModel().selectFirst();

        ChoiceBox<String> role = new ChoiceBox<>();
        role.getItems().addAll("Admin", "Receptionist", "Laundry Staff");
        role.getSelectionModel().selectFirst();

        DatePicker dob = new DatePicker();
        dob.setPromptText("Date of Birth");

        Button addBtn = new Button("Add Employee");
        Button deleteBtn = new Button("Delete Selected");
        deleteBtn.setDisable(true); // default disabled

        // --- DISABLE DELETE KALAU ADMIN PILIH DIRI SENDIRI ---
        ChangeListener<User> rowSelectListener = (obs, oldVal, newVal) -> {
            if (newVal == null) {
                deleteBtn.setDisable(true);
                return;
            }

            if (loggedInUser != null && newVal.getUserID().equals(loggedInUser.getUserID())) {
                deleteBtn.setDisable(true); // admin tidak bisa delete dirinya
            } else {
                deleteBtn.setDisable(false);
            }
        };
        table.getSelectionModel().selectedItemProperty().addListener(rowSelectListener);

        // --- ADD EMPLOYEE ---
        addBtn.setOnAction(e -> {
            try {
                LocalDate d = dob.getValue();
                userController.addEmployee(
                        name.getText(),
                        email.getText(),
                        pass.getText(),
                        conf.getText(),
                        gender.getValue(),
                        d,
                        role.getValue()
                );

                AlertUtil.showInfo(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Success", "Employee added!");

                refresh();

            } catch (IllegalArgumentException iae) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Validation", iae.getMessage());

            } catch (Exception ex) {
                ex.printStackTrace();
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", ex.getMessage());
            }
        });

        // --- DELETE EMPLOYEE (FINAL IMPLEMENTATION) ---
        deleteBtn.setOnAction(e -> {
            User sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", "Select a user first.");
                return;
            }

            try {
                userController.deleteEmployee(loggedInUser, sel);

                AlertUtil.showInfo(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Success", "Employee deleted.");

                refresh();
                deleteBtn.setDisable(true);

            } catch (IllegalArgumentException err) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", err.getMessage());

            } catch (Exception ex) {
                ex.printStackTrace();
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", "Failed to delete employee.");
            }
        });

        right.getChildren().addAll(
                new Label("Add Employee"),
                name, email, pass, conf,
                gender, role, dob,
                addBtn, deleteBtn
        );

        root.setCenter(table);
        root.setRight(right);
    }

    private void setupTable() {
        TableColumn<User, String> c1 = new TableColumn<>("Name");
        c1.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getUserName()));

        TableColumn<User, String> c2 = new TableColumn<>("Email");
        c2.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getUserEmail()));

        TableColumn<User, String> c3 = new TableColumn<>("Role");
        c3.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getUserRole()));

        table.getColumns().addAll(c1, c2, c3);
        table.setItems(data);
    }

    private void refresh() {
        List<User> all = userController.getAllEmployees();
        data.setAll(all);
    }

    public Parent getRoot() { return root; }
}