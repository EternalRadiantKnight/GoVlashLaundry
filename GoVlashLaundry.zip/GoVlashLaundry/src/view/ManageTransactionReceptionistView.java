package view;

import controller.TransactionController;
import controller.UserController;
import entity.Transaction;
import entity.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.util.List;

public class ManageTransactionReceptionistView {

    private VBox root = new VBox(10);
    private TableView<Transaction> table = new TableView<>();
    private ObservableList<Transaction> data = FXCollections.observableArrayList();

    private TransactionController txCtrl = new TransactionController();
    private UserController userCtrl = new UserController();

    public ManageTransactionReceptionistView() {
        root.setPadding(new Insets(20));

        Label title = new Label("Pending Transactions");
        root.getChildren().add(title);

        setupTable();
        root.getChildren().add(table);

        // ComboBox untuk pilih Laundry Staff
        ComboBox<User> staffDropdown = new ComboBox<>();
        List<User> staffList = userCtrl.getUsersByRole("Laundry Staff");
        staffDropdown.setItems(FXCollections.observableArrayList(staffList));
        root.getChildren().add(staffDropdown);

        // Tampilkan nama di dropdown
        staffDropdown.setCellFactory(lv -> new ListCell<User>() {
            @Override
            protected void updateItem(User item, boolean empty) {
                super.updateItem(item, empty);
                setText((empty || item == null) ? null : item.getUserName());
            }
        });

        // Tampilkan nama saat item dipilih
        staffDropdown.setButtonCell(new ListCell<User>() {
            @Override
            protected void updateItem(User item, boolean empty) {
                super.updateItem(item, empty);
                setText((empty || item == null) ? null : item.getUserName());
            }
        });

        Button assignBtn = new Button("Assign to Laundry Staff");
        root.getChildren().add(assignBtn);

        assignBtn.setOnAction(e -> {
            Transaction selectedTx = table.getSelectionModel().getSelectedItem();
            User selectedStaff = staffDropdown.getSelectionModel().getSelectedItem();
            User loggedInReceptionist = userCtrl.getLoggedInUser(); // ambil receptionist yang login

            if (selectedTx == null) {
                showAlert("Error", "Pilih transaksi terlebih dahulu!");
                return;
            }
            if (selectedStaff == null) {
                showAlert("Error", "Pilih laundry staff terlebih dahulu!");
                return;
            }
            if (loggedInReceptionist == null) {
                showAlert("Error", "Receptionist belum login!");
                return;
            }

            try {
                // Assign dengan receptionistID otomatis
                txCtrl.assignOrderToLaundryStaff(
                        selectedTx.getTransactionID(),
                        loggedInReceptionist.getUserID(),
                        selectedStaff.getUserID()
                );
                showAlert("Success", "Transaksi berhasil di-assign!");
                refreshTable();
            } catch (IllegalArgumentException iae) {
                showAlert("Validation", iae.getMessage());
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert("Error", "Gagal assign transaksi.");
            }
        });

        refreshTable(); // initial load
    }

    private void setupTable() {
        TableColumn<Transaction, String> c1 = new TableColumn<>("Tx ID");
        c1.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(String.valueOf(cell.getValue().getTransactionID())));

        TableColumn<Transaction, String> c2 = new TableColumn<>("CustomerID");
        c2.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(String.valueOf(cell.getValue().getCustomerID())));

        TableColumn<Transaction, String> c3 = new TableColumn<>("ServiceID");
        c3.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(String.valueOf(cell.getValue().getServiceID())));

        TableColumn<Transaction, String> c4 = new TableColumn<>("Date");
        c4.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(String.valueOf(cell.getValue().getTransactionDate())));

        TableColumn<Transaction, String> c5 = new TableColumn<>("Status");
        c5.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(cell.getValue().getTransactionStatus()));

        TableColumn<Transaction, String> c6 = new TableColumn<>("Receptionist");
        c6.setCellValueFactory(cell -> {
            Integer id = cell.getValue().getReceptionistID();
            if (id == null) return new javafx.beans.property.SimpleStringProperty("-");
            User receptionist = userCtrl.getUserByID(id);
            return new javafx.beans.property.SimpleStringProperty(receptionist != null ? receptionist.getUserName() : "-");
        });

        TableColumn<Transaction, String> c7 = new TableColumn<>("LaundryStaff");
        c7.setCellValueFactory(cell -> {
            Integer id = cell.getValue().getLaundryStaffID();
            if (id == null) return new javafx.beans.property.SimpleStringProperty("-");
            User staff = userCtrl.getUserByID(id);
            return new javafx.beans.property.SimpleStringProperty(staff != null ? staff.getUserName() : "-");
        });

        TableColumn<Transaction, String> c8 = new TableColumn<>("Notes");
        c8.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(
                cell.getValue().getTransactionNotes() == null ? "" : cell.getValue().getTransactionNotes()));

        table.getColumns().addAll(c1, c2, c3, c4, c5, c6, c7, c8);
        table.setItems(data);

        c1.setPrefWidth(70);
        c2.setPrefWidth(90);
        c3.setPrefWidth(80);
        c4.setPrefWidth(110);
        c5.setPrefWidth(100);
        c6.setPrefWidth(120);
        c7.setPrefWidth(120);
        c8.setPrefWidth(200);
    }

    private void refreshTable() {
        List<Transaction> pendingTx = txCtrl.getTransactionsByStatus("Pending");
        data.setAll(pendingTx);
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    public Parent getRoot() { return root; }
}