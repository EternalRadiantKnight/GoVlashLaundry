package view;

import entity.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

import java.util.function.Consumer;

public class CustomerMenuView {

    private VBox root;
    private Runnable onBack;
    private Runnable onLogout;
    private User user;

    public CustomerMenuView(Runnable onBack, Runnable onLogout, User user) {
        this.onBack = onBack;
        this.onLogout = onLogout;
        this.user = user;
        root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Button orderService = new Button("Order Service");
        Button history = new Button("My Transactions");
        Button notifications = new Button("Notifications");
        Button logout = new Button("Logout");

        root.getChildren().addAll(orderService, history, notifications, logout);

        orderService.setOnAction(e -> {
            CustomerServiceListView v = new CustomerServiceListView(selectedService -> {
                CustomerOrderView ov = new CustomerOrderView(user.getUserID(), selectedService);
                StageHelper.showDialog("Order Service", ov.getRoot());
            });

            StageHelper.showDialog("Choose Service", v.getRoot());
        });


        history.setOnAction(e -> {
            CustomerTransactionHistoryView v = new CustomerTransactionHistoryView(user.getUserID());
            StageHelper.showDialog("My Transactions", v.getRoot());
        });

        notifications.setOnAction(e -> {
            NotificationListView v = new NotificationListView(user.getUserID());
            StageHelper.showDialog("Notifications", v.getRoot());
        });

        logout.setOnAction(e -> { if (onLogout != null) onLogout.run(); });
    }

    public Parent getRoot() { return root; }
}