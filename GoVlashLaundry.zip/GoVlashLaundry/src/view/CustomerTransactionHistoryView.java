package view;

import controller.TransactionController;
import controller.ServiceController;
import entity.Transaction;
import entity.Service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.BorderPane;
import javafx.beans.property.SimpleStringProperty;

import java.util.List;

public class CustomerTransactionHistoryView {

    private BorderPane root;
    private TransactionController txController = new TransactionController();
    private ServiceController serviceController = new ServiceController();
    private TableView<Transaction> table = new TableView<>();
    private ObservableList<Transaction> data = FXCollections.observableArrayList();
    private Integer customerID;

    public CustomerTransactionHistoryView(Integer customerID) {
        this.customerID = customerID;
        root = new BorderPane();
        root.setPadding(new Insets(8));
        setupTable();
        refresh();
        root.setCenter(table);
    }

    private void setupTable() {

        // --- Service Name Column ---
        TableColumn<Transaction, String> cName = new TableColumn<>("Service");
        cName.setCellValueFactory(cell -> {
            Service s = serviceController.getAllServices()
                    .stream()
                    .filter(v -> v.getServiceID().equals(cell.getValue().getServiceID()))
                    .findFirst()
                    .orElse(null);
            return new SimpleStringProperty(s != null ? s.getServiceName() : "-");
        });

        // --- Service Description Column ---
        TableColumn<Transaction, String> cDesc = new TableColumn<>("Description");
        cDesc.setCellValueFactory(cell -> {
            Service s = serviceController.getAllServices()
                    .stream()
                    .filter(v -> v.getServiceID().equals(cell.getValue().getServiceID()))
                    .findFirst()
                    .orElse(null);
            return new SimpleStringProperty(s != null ? s.getServiceDescription() : "-");
        });

        // --- Weight Column ---
        TableColumn<Transaction, String> cWeight = new TableColumn<>("Weight (kg)");
        cWeight.setCellValueFactory(cell ->
                new SimpleStringProperty(String.valueOf(cell.getValue().getTotalWeight()))
        );

        // --- Notes Column ---
        TableColumn<Transaction, String> cNotes = new TableColumn<>("Notes");
        cNotes.setCellValueFactory(cell ->
                new SimpleStringProperty(
                        cell.getValue().getTransactionNotes() != null ? cell.getValue().getTransactionNotes() : "-"
                )
        );

        // --- Transaction Date Column ---
        TableColumn<Transaction, String> cDate = new TableColumn<>("Date");
        cDate.setCellValueFactory(cell ->
                new SimpleStringProperty(String.valueOf(cell.getValue().getTransactionDate()))
        );

        // --- Status Column ---
        TableColumn<Transaction, String> cStatus = new TableColumn<>("Status");
        cStatus.setCellValueFactory(cell ->
                new SimpleStringProperty(cell.getValue().getTransactionStatus())
        );

        table.getColumns().addAll(cName, cDesc, cWeight, cNotes, cDate, cStatus);
        table.setItems(data);
    }

    private void refresh() {
        List<Transaction> list = txController.getTransactionsByCustomerID(customerID);
        data.setAll(list);
    }

    public Parent getRoot() { return root; }
}