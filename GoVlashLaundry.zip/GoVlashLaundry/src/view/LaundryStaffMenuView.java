package view;

import controller.TransactionController;
import entity.Transaction;
import entity.LaundryStaff;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.util.List;

public class LaundryStaffMenuView {

    private VBox root;
    private Runnable onBack;
    private Runnable onLogout;
    private LaundryStaff loggedStaff; // Staff yang login
    private TransactionController txCtrl = new TransactionController();

    public LaundryStaffMenuView(LaundryStaff staff, Runnable onBack, Runnable onLogout) {
        this.loggedStaff = staff;
        this.onBack = onBack;
        this.onLogout = onLogout;

        root = new VBox(10);
        root.setPadding(new Insets(20));
        root.setAlignment(Pos.CENTER);

        Button myAssigned = new Button("My Assigned Orders");
        Button back = new Button("Back");
        Button logout = new Button("Logout");

        root.getChildren().addAll(myAssigned, back, logout);

        myAssigned.setOnAction(e -> showAssignedOrders());
        back.setOnAction(e -> { if (onBack != null) onBack.run(); });
        logout.setOnAction(e -> { if (onLogout != null) onLogout.run(); });
    }

    private void showAssignedOrders() {
        // Ambil semua transaksi yang di-assign ke staff ini
        List<Transaction> assigned = txCtrl.getAssignedOrdersByLaundryStaffID(loggedStaff.getUserID());
        ObservableList<Transaction> data = FXCollections.observableArrayList(assigned);

        TableView<Transaction> table = new TableView<>(data);

        TableColumn<Transaction, String> c1 = new TableColumn<>("Tx ID");
        c1.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(
                String.valueOf(cell.getValue().getTransactionID())));

        TableColumn<Transaction, String> c2 = new TableColumn<>("CustomerID");
        c2.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(
                String.valueOf(cell.getValue().getCustomerID())));

        TableColumn<Transaction, String> c3 = new TableColumn<>("ServiceID");
        c3.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(
                String.valueOf(cell.getValue().getServiceID())));

        TableColumn<Transaction, String> c4 = new TableColumn<>("Status");
        c4.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(
                cell.getValue().getTransactionStatus()));

        TableColumn<Transaction, String> c5 = new TableColumn<>("Notes");
        c5.setCellValueFactory(cell -> new javafx.beans.property.SimpleStringProperty(
                cell.getValue().getTransactionNotes() == null ? "" : cell.getValue().getTransactionNotes()));

        table.getColumns().addAll(c1, c2, c3, c4, c5);

        Button markFinished = new Button("Mark as Finished");
        markFinished.setOnAction(e -> {
            Transaction selected = table.getSelectionModel().getSelectedItem();
            if (selected == null) {
                showAlert("Error", "Pilih transaksi terlebih dahulu!");
                return;
            }
            try {
                txCtrl.updateTransactionStatus(selected.getTransactionID(), "Finished");
                showAlert("Success", "Transaksi berhasil di-mark as finished!");
                // refresh table
                data.setAll(txCtrl.getAssignedOrdersByLaundryStaffID(loggedStaff.getUserID()));
            } catch (Exception ex) {
                ex.printStackTrace();
                showAlert("Error", "Gagal update status transaksi.");
            }
        });

        VBox dialogRoot = new VBox(10);
        dialogRoot.setPadding(new Insets(20));
        dialogRoot.getChildren().addAll(table, markFinished);

        StageHelper.showDialog("My Assigned Orders", dialogRoot);
    }

    private void showAlert(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    public Parent getRoot() { return root; }
}