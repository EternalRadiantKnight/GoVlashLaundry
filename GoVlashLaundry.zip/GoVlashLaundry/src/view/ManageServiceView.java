package view;

import controller.ServiceController;
import entity.Service;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import util.AlertUtil;

import java.util.List;

public class ManageServiceView {

    private BorderPane root;
    private ServiceController serviceController = new ServiceController();
    private TableView<Service> table = new TableView<>();
    private ObservableList<Service> data = FXCollections.observableArrayList();

    public ManageServiceView() {
        root = new BorderPane();
        root.setPadding(new Insets(10));
        setupTable();
        refresh();

        // === PERBESAR AREA TABLE ===
        table.setPrefWidth(500); 
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        VBox right = new VBox(6);
        right.setPadding(new Insets(6));

        TextField name = new TextField(); 
        name.setPromptText("Service name");

        TextArea desc = new TextArea(); 
        desc.setPromptText("Description"); 
        desc.setPrefRowCount(3);

        TextField price = new TextField(); 
        price.setPromptText("Price");

        TextField duration = new TextField(); 
        duration.setPromptText("Duration (days)");

        Button add = new Button("Add");
        Button edit = new Button("Edit Selected");
        Button del = new Button("Delete Selected");

        // === AUTO FILL FORM SAAT KLIK TABLE ===
        table.getSelectionModel().selectedItemProperty().addListener((obs, oldVal, sel) -> {
            if (sel != null) {
                name.setText(sel.getServiceName());
                desc.setText(sel.getServiceDescription());
                price.setText(String.valueOf(sel.getServicePrice()));
                duration.setText(String.valueOf(sel.getServiceDuration()));
            }
        });

        // ADD SERVICE
        add.setOnAction(e -> {
            try {
                Double p = Double.parseDouble(price.getText());
                Integer d = Integer.parseInt(duration.getText());
                serviceController.addService(name.getText(), desc.getText(), p, d);

                AlertUtil.showInfo(root.getScene().getWindow(), "Sukses", "Service ditambahkan.");
                refresh();
            } catch (NumberFormatException nfe) {
                AlertUtil.showError(root.getScene().getWindow(), "Format error", "Price/duration invalid.");
            } catch (IllegalArgumentException iae) {
                AlertUtil.showError(root.getScene().getWindow(), "Validation", iae.getMessage());
            }
        });

        // EDIT SERVICE
        edit.setOnAction(e -> {
            Service sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) {
                AlertUtil.showError(root.getScene().getWindow(), "Error", "Pilih service");
                return;
            }

            try {
                Double p = Double.parseDouble(price.getText());
                Integer d = Integer.parseInt(duration.getText());
                serviceController.editService(sel.getServiceID(), name.getText(), desc.getText(), p, d);

                AlertUtil.showInfo(root.getScene().getWindow(), "Sukses", "Service diupdate.");
                refresh();
            } catch (Exception ex) {
                AlertUtil.showError(root.getScene().getWindow(), "Error", ex.getMessage());
            }
        });

        // DELETE SERVICE
        del.setOnAction(e -> {
            Service sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) {
                AlertUtil.showError(root.getScene().getWindow(), "Error", "Pilih service");
                return;
            }

            boolean ok = AlertUtil.confirm(root.getScene().getWindow(),
                    "Confirm", "Hapus service " + sel.getServiceName() + " ?");

            if (!ok) return;

            try {
                serviceController.deleteService(sel.getServiceID());
                AlertUtil.showInfo(root.getScene().getWindow(), "Sukses", "Service dihapus.");
                refresh();
            } catch (Exception ex) {
                AlertUtil.showError(root.getScene().getWindow(), "Error", ex.getMessage());
            }
        });

        right.getChildren().addAll(
                new Label("Service Form"),
                name, desc, price, duration,
                add, edit, del
        );

        root.setCenter(table);
        root.setRight(right);
    }

    private void setupTable() {
        TableColumn<Service, String> c1 = new TableColumn<>("Name");
        c1.setCellValueFactory(cell -> 
            new javafx.beans.property.SimpleStringProperty(cell.getValue().getServiceName())
        );

        TableColumn<Service, String> c2 = new TableColumn<>("Price");
        c2.setCellValueFactory(cell ->
            new javafx.beans.property.SimpleStringProperty(String.valueOf(cell.getValue().getServicePrice()))
        );

        TableColumn<Service, String> c3 = new TableColumn<>("Duration");
        c3.setCellValueFactory(cell ->
            new javafx.beans.property.SimpleStringProperty(String.valueOf(cell.getValue().getServiceDuration()))
        );

        table.getColumns().addAll(c1, c2, c3);
        table.setItems(data);
    }

    private void refresh() {
        List<Service> list = serviceController.getAllServices();
        data.setAll(list);
    }

    public Parent getRoot() { return root; }
}