package view;

import controller.TransactionController;
import entity.Service;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import util.AlertUtil;

public class CustomerOrderView {

    private VBox root = new VBox(10);
    private TransactionController txCtrl = new TransactionController();

    public CustomerOrderView(int customerID, Service service) {

        root.setPadding(new Insets(20));

        Label sName = new Label("Service: " + service.getServiceName());
        Label sPrice = new Label("Price: Rp " + service.getServicePrice());

        TextField weightField = new TextField();
        weightField.setPromptText("Total weight (2 - 50 kg)");

        TextField notesField = new TextField();
        notesField.setPromptText("Optional notes");

        Button orderBtn = new Button("Confirm Order");

        orderBtn.setOnAction(e -> {
            try {
                double w = Double.parseDouble(weightField.getText());
                txCtrl.orderLaundryService(service.getServiceID(), customerID, w, notesField.getText());
                AlertUtil.showInfo(null, "Success", "Order created successfully!");
            } catch (Exception ex) {
                ex.printStackTrace();
                AlertUtil.showError(null, "Error", ex.getMessage());
            }
        });

        root.getChildren().addAll(sName, sPrice, weightField, notesField, orderBtn);
    }

    public Parent getRoot() { return root; }
}