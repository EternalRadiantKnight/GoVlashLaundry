package view;

import controller.UserController;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import util.AlertUtil;

import java.time.LocalDate;

public class RegisterCustomerView {

    private VBox root;
    private UserController userController = new UserController();
    private Runnable onSuccess;

    public RegisterCustomerView(Runnable onSuccess) {
        this.onSuccess = onSuccess;
        root = new VBox(8);
        root.setPadding(new Insets(12));
        root.setAlignment(Pos.CENTER_LEFT);
        root.setPrefWidth(450);

        TextField nameField = new TextField();
        nameField.setPromptText("Full name");

        TextField emailField = new TextField();
        emailField.setPromptText("Email (must end with @email.com)");

        PasswordField passField = new PasswordField();
        passField.setPromptText("Password (min 6 char)");

        PasswordField confirmField = new PasswordField();
        confirmField.setPromptText("Confirm password");

        ChoiceBox<String> genderBox = new ChoiceBox<>();
        genderBox.getItems().addAll("Male", "Female");
        genderBox.getSelectionModel().selectFirst();

        DatePicker dobPicker = new DatePicker();
        dobPicker.setPromptText("Select Date of Birth");

        Button submit = new Button("Register");
        root.getChildren().addAll(
                new Label("Register Customer"),
                new Label("Name"), nameField,
                new Label("Email"), emailField,
                new Label("Password"), passField,
                new Label("Confirm Password"), confirmField,
                new Label("Gender"), genderBox,
                new Label("DOB"), dobPicker,
                submit
        );

        submit.setOnAction(ev -> {
            String name = nameField.getText();
            String email = emailField.getText();
            String pass = passField.getText();
            String confirm = confirmField.getText();
            String gender = genderBox.getValue();
            LocalDate dob = dobPicker.getValue();

            if (dob == null) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Invalid DOB", "Please select a valid date.");
                return;
            }

            try {
                userController.addUser(name, email, pass, confirm, gender, dob, "Customer");
                AlertUtil.showInfo(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Success", "Customer registered successfully.");
                
                if (onSuccess != null) onSuccess.run();
                StageHelper.closeOwner(root);

            } catch (IllegalArgumentException iae) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Validation", iae.getMessage());
            } catch (Exception ex) {
                ex.printStackTrace();
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", ex.getMessage());
            }
        });
    }

    public Parent getRoot() { return root; }
}