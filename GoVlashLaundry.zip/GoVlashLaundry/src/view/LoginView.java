package view;

import controller.UserController;
import entity.User;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import util.AlertUtil;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.function.Consumer;

public class LoginView {

    private BorderPane root;
    private UserController userController = new UserController();

    public LoginView(Consumer<User> onLoginSuccess) {
        root = new BorderPane();
        root.setPadding(new Insets(20));

        VBox box = new VBox(10);
        box.setMaxWidth(400);
        box.setAlignment(Pos.CENTER);

        Label title = new Label("GoVlash Laundry - Login");
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");

        TextField emailField = new TextField();
        emailField.setPromptText("Email");

        PasswordField passField = new PasswordField();
        passField.setPromptText("Password");

        Button loginBtn = new Button("Login");
        Button registerBtn = new Button("Register");

        HBox btns = new HBox(10, loginBtn, registerBtn);
        btns.setAlignment(Pos.CENTER);

        box.getChildren().addAll(title, emailField, passField, btns);
        root.setCenter(box);

        loginBtn.setOnAction(ev -> {
            String email = emailField.getText();
            String pass = passField.getText();
            try {
                User u = userController.login(email, pass);
                if (u == null) {
                    AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(), "Login Failed", "Email atau password salah.");
                    return;
                }
                onLoginSuccess.accept(u);
            } catch (Exception ex) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(), "Error", ex.getMessage());
            }
        });

        registerBtn.setOnAction(ev -> {
            RegisterCustomerView rv = new RegisterCustomerView(() -> {
                AlertUtil.showInfo(root.getScene() == null ? null : root.getScene().getWindow(), "Success", "Registrasi berhasil. Silakan login.");
            });
            StageHelper.showDialog("Register Customer", rv.getRoot());
        });
    }

    public Parent getRoot() { return root; }
}