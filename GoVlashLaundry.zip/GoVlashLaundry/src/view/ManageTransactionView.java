package view;

import controller.TransactionController;
import controller.NotificationController;
import controller.ServiceController;
import controller.UserController;
import entity.Service;
import entity.Transaction;
import entity.User;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Parent;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import util.AlertUtil;

import java.util.List;
import javafx.beans.property.SimpleStringProperty;

public class ManageTransactionView {

    private BorderPane root;
    private TransactionController txController = new TransactionController();
    private NotificationController notifController = new NotificationController();
    private ServiceController serviceController = new ServiceController();
    private UserController userController = new UserController();

    private TableView<Transaction> table = new TableView<>();
    private ObservableList<Transaction> data = FXCollections.observableArrayList();

    public ManageTransactionView() {
        root = new BorderPane();
        root.setPadding(new Insets(8));
        setupTable();

        // top: filter + refresh
        HBox top = new HBox(8);
        top.setPadding(new Insets(6));

        ChoiceBox<String> filterStatus = new ChoiceBox<>();
        filterStatus.getItems().addAll("All", "Pending", "In Progress", "Finished");
        filterStatus.getSelectionModel().selectFirst();

        Button refreshBtn = new Button("Refresh");
        top.getChildren().addAll(new Label("Filter by status:"), filterStatus, refreshBtn);
        root.setTop(top);

        refreshBtn.setOnAction(e -> loadByFilter(filterStatus.getValue()));
        filterStatus.setOnAction(e -> loadByFilter(filterStatus.getValue()));

        // right: actions allowed to admin (only view + send notification for finished)
        VBox right = new VBox(8);
        right.setPadding(new Insets(8));
        Button sendNotifBtn = new Button("Send 'Finished' Notification");
        sendNotifBtn.setDisable(true);
        Button viewDetailBtn = new Button("View Selected Details");

        right.getChildren().addAll(new Label("Admin actions"), sendNotifBtn, viewDetailBtn);
        root.setRight(right);

        // center table
        root.setCenter(table);
        refresh(); // initial load

        // selection listener: enable sendNotif only if selected & status == Finished
        table.getSelectionModel().selectedItemProperty().addListener((obs, oldSel, newSel) -> {
            if (newSel == null) {
                sendNotifBtn.setDisable(true);
                viewDetailBtn.setDisable(true);
            } else {
                viewDetailBtn.setDisable(false);
                boolean finished = "Finished".equalsIgnoreCase(newSel.getTransactionStatus());
                sendNotifBtn.setDisable(!finished);
            }
        });

        // send notification action (admin-triggered)
        sendNotifBtn.setOnAction(e -> {
            Transaction sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", "Pilih transaksi yang sudah selesai.");
                return;
            }
            if (!"Finished".equalsIgnoreCase(sel.getTransactionStatus())) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", "Notifikasi hanya bisa dikirim untuk transaksi berstatus Finished.");
                return;
            }
            boolean ok = AlertUtil.confirm(root.getScene() == null ? null : root.getScene().getWindow(),
                    "Confirm", "Kirim notifikasi ke customer untuk transaksi ID " + sel.getTransactionID() + " ?");
            if (!ok) return;

            try {
                // menggunakan helper di controller untuk membuat pesan otomatis
                notifController.sendFinishedNotificationByTransaction(sel.getTransactionID());
                AlertUtil.showInfo(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Sukses", "Notifikasi dikirim ke customer.");
            } catch (IllegalArgumentException iae) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Validation", iae.getMessage());
            } catch (Exception ex) {
                ex.printStackTrace();
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", "Gagal mengirim notifikasi.");
            }
        });

        // view detail action (show friendly names instead of raw IDs)
        viewDetailBtn.setOnAction(e -> {
            Transaction sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) {
                AlertUtil.showError(root.getScene() == null ? null : root.getScene().getWindow(),
                        "Error", "Pilih transaksi.");
                return;
            }

            // --- Ambil Service ---
            Service service = serviceController.getAllServices()
                    .stream()
                    .filter(s -> s.getServiceID().equals(sel.getServiceID()))
                    .findFirst()
                    .orElse(null);

            // --- Ambil Customer Name ---
            User customer = sel.getCustomerID() == null ? null : userController.getUserByID(sel.getCustomerID());

            // --- Ambil Receptionist Name (bisa null) ---
            User receptionist = sel.getReceptionistID() == null
                    ? null
                    : userController.getUserByID(sel.getReceptionistID());

            // --- Ambil Laundry Staff Name (bisa null) ---
            User staff = sel.getLaundryStaffID() == null
                    ? null
                    : userController.getUserByID(sel.getLaundryStaffID());

            StringBuilder sb = new StringBuilder();
            sb.append("Transaction ID: ").append(sel.getTransactionID()).append("\n\n");

            sb.append("Customer: ").append(customer != null ? customer.getUserName() : "-").append("\n");
            sb.append("Service: ").append(service != null ? service.getServiceName() : "-").append("\n");
            sb.append("Description: ").append(service != null ? service.getServiceDescription() : "-").append("\n\n");

            sb.append("Date: ").append(sel.getTransactionDate()).append("\n");
            sb.append("Status: ").append(sel.getTransactionStatus()).append("\n\n");

            sb.append("Receptionist: ").append(receptionist != null ? receptionist.getUserName() : "-").append("\n");
            sb.append("Laundry Staff: ").append(staff != null ? staff.getUserName() : "-").append("\n\n");

            sb.append("Total Weight: ").append(sel.getTotalWeight() != null ? sel.getTotalWeight() + " kg" : "-").append("\n");
            sb.append("Notes: ").append(sel.getTransactionNotes() != null ? sel.getTransactionNotes() : "-").append("\n");

            AlertUtil.showInfo(root.getScene() == null ? null : root.getScene().getWindow(),
                    "Transaction Detail", sb.toString());
        });
    }

    private void setupTable() {
        // Tx ID
        TableColumn<Transaction, String> c1 = new TableColumn<>("Tx ID");
        c1.setCellValueFactory(cell -> new SimpleStringProperty(
                cell.getValue().getTransactionID() == null ? "-" : String.valueOf(cell.getValue().getTransactionID())
        ));

        // Customer name (instead of ID)
        TableColumn<Transaction, String> c2 = new TableColumn<>("Customer");
        c2.setCellValueFactory(cell -> {
            Integer custId = cell.getValue().getCustomerID();
            if (custId == null) return new SimpleStringProperty("-");
            User u = userController.getUserByID(custId);
            return new SimpleStringProperty(u != null ? u.getUserName() : String.valueOf(custId));
        });

        // Service name (instead of ID)
        TableColumn<Transaction, String> c3 = new TableColumn<>("Service");
        c3.setCellValueFactory(cell -> {
            Integer sid = cell.getValue().getServiceID();
            if (sid == null) return new SimpleStringProperty("-");
            Service s = serviceController.getAllServices()
                    .stream()
                    .filter(v -> v.getServiceID().equals(sid))
                    .findFirst()
                    .orElse(null);
            return new SimpleStringProperty(s != null ? s.getServiceName() : String.valueOf(sid));
        });

        // Date
        TableColumn<Transaction, String> c4 = new TableColumn<>("Date");
        c4.setCellValueFactory(cell -> new SimpleStringProperty(
                cell.getValue().getTransactionDate() == null ? "-" : String.valueOf(cell.getValue().getTransactionDate())
        ));

        // Status
        TableColumn<Transaction, String> c5 = new TableColumn<>("Status");
        c5.setCellValueFactory(cell -> new SimpleStringProperty(
                cell.getValue().getTransactionStatus() == null ? "-" : cell.getValue().getTransactionStatus()
        ));

        // Receptionist name
        TableColumn<Transaction, String> c6 = new TableColumn<>("Receptionist");
        c6.setCellValueFactory(cell -> {
            Integer id = cell.getValue().getReceptionistID();
            if (id == null) return new SimpleStringProperty("-");
            User u = userController.getUserByID(id);
            return new SimpleStringProperty(u != null ? u.getUserName() : String.valueOf(id));
        });

        // Laundry staff name
        TableColumn<Transaction, String> c7 = new TableColumn<>("Laundry Staff");
        c7.setCellValueFactory(cell -> {
            Integer id = cell.getValue().getLaundryStaffID();
            if (id == null) return new SimpleStringProperty("-");
            User u = userController.getUserByID(id);
            return new SimpleStringProperty(u != null ? u.getUserName() : String.valueOf(id));
        });

        table.getColumns().addAll(c1, c2, c3, c4, c5, c6, c7);
        table.setItems(data);

        // set column widths roughly so admin won't need to scroll horizontally so much
        c1.setPrefWidth(70);
        c2.setPrefWidth(130);
        c3.setPrefWidth(150);
        c4.setPrefWidth(110);
        c5.setPrefWidth(110);
        c6.setPrefWidth(140);
        c7.setPrefWidth(140);
    }

    private void refresh() {
        List<Transaction> list = txController.getAllTransactions();
        data.setAll(list);
    }

    private void loadByFilter(String status) {
        if ("All".equalsIgnoreCase(status) || status == null) {
            refresh();
            return;
        }
        List<Transaction> list = txController.getTransactionsByStatus(status);
        data.setAll(list);
    }

    public Parent getRoot() { return root; }
}