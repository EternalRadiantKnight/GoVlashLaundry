package controller;

import model.TransactionModel;
import entity.Transaction;

import java.util.List;

public class TransactionController {

    private TransactionModel model = new TransactionModel();

    /**
     * getAllTransactions() : List<Transaction>
     */
    public List<Transaction> getAllTransactions() {
        return model.getAllTransactions();
    }

    /**
     * getTransactionsByStatus(status) : List<Transaction>
     */
    public List<Transaction> getTransactionsByStatus(String status) {
        return model.getTransactionsByStatus(status);
    }

    /**
     * updateTransactionStatus(transactionID, status) : void
     */
    public void updateTransactionStatus(Integer transactionID, String status) {
        if (transactionID == null) throw new IllegalArgumentException("TransactionID harus ada.");
        Transaction t = model.getTransactionByID(transactionID);
        if (t == null) throw new IllegalArgumentException("Transaction tidak ditemukan.");
        t.setTransactionStatus(status);
        boolean ok = model.updateTransaction(t);
        if (!ok) throw new RuntimeException("Gagal update status.");
    }

    /**
     * getAssignedOrdersByLaundryStaffID(laundryStaffID) : List<Transaction>
     */
    public List<Transaction> getAssignedOrdersByLaundryStaffID(Integer laundryStaffID) {
        List<Transaction> all = model.getAllTransactions();
        java.util.List<Transaction> filtered = new java.util.ArrayList<>();
        for (Transaction t : all) {
            if (laundryStaffID != null && laundryStaffID.equals(t.getLaundryStaffID())) filtered.add(t);
        }
        return filtered;
    }

    /**
     * assignOrderToLaundryStaff(transactionID, receptionistID, laundryStaffID) : void
     */
    public void assignOrderToLaundryStaff(Integer transactionID, Integer receptionistID, Integer laundryStaffID) {
        if (transactionID == null || receptionistID == null || laundryStaffID == null) throw new IllegalArgumentException("Parameter kurang.");
        boolean ok = model.assignOrderToLaundryStaff(transactionID, receptionistID, laundryStaffID);
        if (!ok) throw new RuntimeException("Gagal assign order.");
    }

    /**
     * orderLaundryService(serviceID, customerID, totalWeight, notes) : void
     */
    public void orderLaundryService(Integer serviceID, Integer customerID, Double totalWeight, String notes) {
        if (serviceID == null || customerID == null || totalWeight == null) throw new IllegalArgumentException("Parameter kurang.");
        String v = validateOrder(totalWeight, notes);
        if (!"OK".equals(v)) throw new IllegalArgumentException(v);
        Transaction t = new Transaction(null, serviceID, customerID, null, null, null, "Pending", totalWeight, notes);
        boolean ok = model.insertTransaction(t);
        if (!ok) throw new RuntimeException("Gagal membuat transaksi.");
    }

    /**
     * getTransactionsByCustomerID(customerID) : List<Transaction>
     */
    public List<Transaction> getTransactionsByCustomerID(Integer customerID) {
        return model.getTransactionsByCustomer(customerID);
    }

    /**
     * validateOrder(totalWeight, notes) : String
     */
    public String validateOrder(Double totalWeight, String notes) {
        if (totalWeight == null) return "Total weight harus diisi.";
        if (totalWeight < 2.0 || totalWeight > 50.0) return "Total weight harus antara 2 dan 50 kg.";
        if (notes != null && notes.length() > 250) return "Notes maksimal 250 karakter.";
        return "OK";
    }
}