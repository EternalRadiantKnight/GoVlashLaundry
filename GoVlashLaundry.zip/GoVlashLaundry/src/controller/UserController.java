package controller;

import model.UserModel;
import entity.User;

import java.time.LocalDate;
import java.time.Period;
import java.util.List;

public class UserController {

    private UserModel model = new UserModel();

    public void addUser(String name, String email, String password, String confirmPassword, String gender, LocalDate dob, String role) {
        String v = validateAddUser(name, email, password, confirmPassword, gender, dob, role);
        if (!"OK".equals(v)) throw new IllegalArgumentException(v);

        User existing = model.getUserByEmail(email);
        if (existing != null) throw new IllegalArgumentException("Email sudah terdaftar.");

        if ("Customer".equals(role)) {
            if (!email.toLowerCase().endsWith("@email.com")) throw new IllegalArgumentException("Email customer harus diakhiri @email.com");
        } else {
            if (!email.toLowerCase().endsWith("@govlash.com")) throw new IllegalArgumentException("Email karyawan harus diakhiri @govlash.com");
        }

        User u = new User(null, name, email, password, gender, dob, role);
        boolean ok = model.insertUser(u);
        if (!ok) throw new RuntimeException("Gagal menyimpan user ke database.");
    }

    public User login(String email, String password) {
        if (email == null || password == null) return null;
        return model.login(email, password);
    }

    public User getUserByID(int id) {
        return model.getUserByID(id);
    }
    
    public User getLoggedInUser() {
        return model.getLastLoggedInUser();
    }

    public void addEmployee(String name, String email, String password, String confirmPassword, String gender, LocalDate dob, String role) {

		String v = validateAddEmployee(name, email, password, confirmPassword, gender, dob, role);
		if (!"OK".equals(v)) throw new IllegalArgumentException(v);
		
		User existing = model.getUserByEmail(email);
		if (existing != null) throw new IllegalArgumentException("Email sudah terdaftar.");
		
		if (!( "Admin".equals(role) || "Receptionist".equals(role) || "Laundry Staff".equals(role))) {
		throw new IllegalArgumentException("Role karyawan harus Admin / Receptionist / Laundry Staff.");
		}
		
		User u = new User(null, name, email, password, gender, dob, role);
		
		boolean ok = model.insertUser(u);
		if (!ok) throw new RuntimeException("Gagal menyimpan employee ke database.");
	}
    
    public void deleteEmployee(User currentAdmin, User target) {

        if (target == null) throw new IllegalArgumentException("User tidak ditemukan.");

        if (currentAdmin.getUserID().equals(target.getUserID())) {
            throw new IllegalArgumentException("Admin tidak boleh menghapus akun sendiri.");
        }

        if (!("Admin".equals(target.getUserRole()) ||
              "Receptionist".equals(target.getUserRole()) ||
              "Laundry Staff".equals(target.getUserRole()))) {

            throw new IllegalArgumentException("Hanya karyawan yang boleh dihapus.");
        }

        boolean ok = model.deleteUser(target.getUserID());
        if (!ok) throw new RuntimeException("Gagal menghapus employee.");
    }
    
    public boolean deleteCustomer(int customerID) {

        User u = model.getUserByID(customerID);
        if (u == null) throw new IllegalArgumentException("Customer tidak ditemukan.");

        if (!"Customer".equals(u.getUserRole()))
            throw new IllegalArgumentException("Hanya customer yang boleh dihapus.");

        return model.deleteUser(customerID);
    }

    public List<User> getAllEmployees() {
        return model.getAllEmployees();
    }
    
    public List<User> getCustomers() {
        return model.getCustomers();
    }

    public boolean deleteCustomer(Integer id) {
        return model.deleteUser(id);
    }

    public List<User> getUsersByRole(String role) {
        List<User> all = model.getAllEmployees(); // model limited to employees; for generic role filtering we can extend model later
        java.util.List<User> filtered = new java.util.ArrayList<>();
        for (User u : all) {
            if (u.getUserRole() != null && u.getUserRole().equals(role)) filtered.add(u);
        }
        return filtered;
    }

    public String validateAddEmployee(String name, String email, String password, String confirmPassword, String gender, LocalDate dob, String role) {
        if (name == null || name.trim().isEmpty()) return "Name tidak boleh kosong.";
        if (email == null || email.trim().isEmpty()) return "Email tidak boleh kosong.";
        if (!email.toLowerCase().endsWith("@govlash.com")) {
            throw new IllegalArgumentException("Email karyawan harus diakhiri @govlash.com");
        }
        if (password == null || password.length() < 6) return "Password minimal 6 karakter.";
        if (!password.equals(confirmPassword)) return "Password dan Confirm Password tidak sama.";
        if (gender != null && !("Male".equals(gender) || "Female".equals(gender))) return "Gender harus Male atau Female.";
        if (dob == null) return "DOB harus diisi.";
        if (role == null || role.trim().isEmpty()) return "Role harus diisi.";
        // minimum age for employee role
        if (Period.between(dob, LocalDate.now()).getYears() < 17) return "Usia karyawan minimal 17 tahun.";
        return "OK";
    }

    public String validateAddCustomer(String name, String email, String password, String confirmPassword, String gender, LocalDate dob) {
        if (name == null || name.trim().isEmpty()) return "Name tidak boleh kosong.";
        if (email == null || email.trim().isEmpty()) return "Email tidak boleh kosong.";
        if (password == null || password.length() < 6) return "Password minimal 6 karakter.";
        if (!password.equals(confirmPassword)) return "Password dan Confirm Password tidak sama.";
        if (!("Male".equals(gender) || "Female".equals(gender))) return "Gender harus Male atau Female.";
        if (dob == null) return "DOB harus diisi.";
        if (Period.between(dob, LocalDate.now()).getYears() < 12) return "Usia customer minimal 12 tahun.";
        // domain constraint for customer email will be enforced in addUser
        return "OK";
    }

    public User getUserByEmail(String email) {
        return model.getUserByEmail(email);
    }

    public User getUserByName(String name) {
        if (name == null) return null;
        return model.getUserByName(name);
    }

    private String validateAddUser(String name, String email, String password, String confirmPassword, String gender, LocalDate dob, String role) {
        if (name == null || name.trim().isEmpty()) return "Name tidak boleh kosong.";
        if (email == null || email.trim().isEmpty()) return "Email tidak boleh kosong.";
        if (password == null || password.length() < 6) return "Password minimal 6 karakter.";
        if (!password.equals(confirmPassword)) return "Password dan Confirm Password tidak sama.";
        if (gender != null && !("Male".equals(gender) || "Female".equals(gender))) return "Gender harus Male atau Female.";
        if (dob == null) return "DOB harus diisi.";
        int minAge = "Customer".equals(role) ? 12 : 17;
        if (Period.between(dob, LocalDate.now()).getYears() < minAge) return "Usia tidak memenuhi syarat.";
        if (role == null || role.trim().isEmpty()) return "Role harus diisi.";
        return "OK";
    }
}