package controller;

import model.ServiceModel;
import entity.Service;

import java.util.List;

public class ServiceController {

    private ServiceModel model = new ServiceModel();

    /**
     * addService(name, description, price, duration) : void
     * Throws IllegalArgumentException when validation fails.
     */
    public void addService(String name, String description, Double price, Integer duration) {
        String v = validateAddService(name, description, price, duration);
        if (!"OK".equals(v)) throw new IllegalArgumentException(v);

        Service s = new Service(null, name, description, price, duration);
        boolean ok = model.insertService(s);
        if (!ok) throw new RuntimeException("Gagal menyimpan service ke database.");
    }

    /**
     * editService(serviceID, name, description, price, duration) : void
     */
    public void editService(Integer serviceID, String name, String description, Double price, Integer duration) {
        if (serviceID == null) throw new IllegalArgumentException("ServiceID harus ada.");
        String v = validateEditService(name, description, price, duration);
        if (!"OK".equals(v)) throw new IllegalArgumentException(v);

        Service s = new Service(serviceID, name, description, price, duration);
        boolean ok = model.updateService(s);
        if (!ok) throw new RuntimeException("Gagal update service.");
    }

    /**
     * deleteService(serviceID) : void
     */
    public void deleteService(Integer serviceID) {
        if (serviceID == null) throw new IllegalArgumentException("ServiceID harus ada.");
        boolean ok = model.deleteService(serviceID);
        if (!ok) throw new RuntimeException("Gagal menghapus service.");
    }

    /**
     * getAllServices() : List<Service>
     */
    public List<Service> getAllServices() {
        return model.getAllServices();
    }

    /**
     * validateAddService(name, description, price, duration) : String
     */
    public String validateAddService(String name, String description, Double price, Integer duration) {
        if (name == null || name.trim().isEmpty()) return "Service Name tidak boleh kosong.";
        if (name.length() > 50) return "Service Name maksimal 50 karakter.";
        if (description == null || description.trim().isEmpty()) return "Service Description tidak boleh kosong.";
        if (description.length() > 250) return "Service Description maksimal 250 karakter.";
        if (price == null) return "Service Price harus diisi.";
        if (price <= 0) return "Service Price harus lebih dari 0.";
        if (duration == null) return "Service Duration harus diisi.";
        if (duration < 1 || duration > 30) return "Service Duration harus antara 1 sampai 30 hari.";
        return "OK";
    }

    /**
     * validateEditService(name, description, price, duration) : String
     */
    public String validateEditService(String name, String description, Double price, Integer duration) {
        return validateAddService(name, description, price, duration);
    }
}