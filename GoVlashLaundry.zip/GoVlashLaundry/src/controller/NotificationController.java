package controller;

import model.NotificationModel;
import model.TransactionModel;
import entity.Notification;

import java.time.LocalDateTime;
import java.util.List;

/**
 * NotificationController implements UML-specified methods.
 *
 * Note: According to UML sendNotification/deleteNotification/markAsRead are void.
 * To report validation errors to caller (view), this controller throws IllegalArgumentException with the message.
 */
public class NotificationController {

    private NotificationModel model = new NotificationModel();
    private TransactionModel txModel = new TransactionModel();

    public void sendNotification(Integer recipientID, String message) {
        if (recipientID == null) throw new IllegalArgumentException("RecipientID harus ada.");
        if (message == null || message.trim().isEmpty()) throw new IllegalArgumentException("Message tidak boleh kosong.");

        Notification n = new Notification(null, recipientID, message, LocalDateTime.now(), false);
        boolean ok = model.insertNotification(n);
        if (!ok) throw new RuntimeException("Gagal mengirim notifikasi.");
    }

    public List<Notification> getNotificationsByRecipientID(Integer recipientID) {
        if (recipientID == null) return java.util.Collections.emptyList();
        return model.getNotificationsByRecipient(recipientID);
    }

    public Notification getNotificationByID(Integer notificationID) {
        if (notificationID == null) return null;
        return model.getNotificationByID(notificationID);
    }

    public void deleteNotification(Integer notificationID) {
        if (notificationID == null) throw new IllegalArgumentException("NotificationID harus ada.");
        boolean ok = model.deleteNotification(notificationID);
        if (!ok) throw new RuntimeException("Gagal menghapus notifikasi.");
    }

    public void markAsRead(Integer notificationID) {
        if (notificationID == null) throw new IllegalArgumentException("NotificationID harus ada.");
        boolean ok = model.markAsRead(notificationID);
        if (!ok) throw new RuntimeException("Gagal menandai sebagai dibaca.");
    }

    public boolean validateIsRead(Notification n) {
        return n != null && Boolean.TRUE.equals(n.getIsRead());
    }

    public void sendFinishedNotificationByTransaction(int transactionID) {
        Integer custId = txModel.getCustomerIDByTransactionID(transactionID);
        if (custId == null) throw new IllegalArgumentException("Transaksi tidak ditemukan.");
        String msg = "Your order (ID " + transactionID + ") is finished and ready for pickup. Thank you for choosing our service!";
        sendNotification(custId, msg);
    }
}